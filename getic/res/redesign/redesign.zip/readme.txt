pb_tvflip - flips a texture vertically (|)
pb_thflip - flips a texture horizontally (-)
pb_trot   - rotates a texture with 90 defrees

tb_align*24.bmp 13 buttons 26x26 pixels  
    1-aligns selected items having same X coord
    2-aligns selected items having same Y coord
    3-aligns selected items having same Z coord
    4-spaces out equidistant selected items on X coord
    5-spaces out equidistant selected items on Y coord
    6-spaces out equidistant selected items on Z coord
    7-resize selected items  to have same X dimension
    8-resize selected items  to have same Y dimension
    9-resize selected items  to have same Z dimension
    10-resize selected items  to have same XYZ dimension
    11-aligns all selectd items along X axes as the first selected item
    12-aligns all selectd items along Y axes as the first selected item
    13-aligns all selectd items along Z axes as the first selected item

tb_build*24.bmp has 9 buttons
    1-complette compile the map level into a BSP file
    2-recalculate te lighting
    3-view just portals in the BSP tree
    4-view the complette scene (final scene)
    5-view leaf zones in the BSP tree
    6-view leaf by leaf in the BSP tree
    7-view the lighting only (see some screens hots at www.zalsoft.com)
    8-view the full tree structure graph (like a wirframe tree structure)
    9-view the visibility zones (like some wireframe volumes)

tb_cgs*24.bpp
    1-perform constructive solid geometry to build a prefabricated body
    2-view the ready build body
    3-save the body in the prefabricated library directory

tb_make
    1-open a file
    2-save a file
    3-create a cube
    4-create a cylinder
    5-a cone
    6-stairs
    7-sheet
    8-sphere
    9-terrain
    10-from 2d to 3d Extrussion tool
    11-insert prefabricated item
    12-insert an item (light bulb, script, other than bodyes/brushes)
    13-2D editor
    14-unused

tb_select*24.bmp
    1-select a body/brush
    2-select a face
    3-select an item
    5-select a point/vertex

tb_sizemove*24.bmp
    1-move an item / or a brush whatever is selectd
    2-scale an item / or a brush whatever is selectd
    3-rotate an item / or a brush whatever is selectd
    4-share an item / or a brush whatever is selectd (like sliding one of the face then ellongating the brush)
    5-reverse selectd brush 






 